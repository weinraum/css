<header class="container-fluid border-bottom mb-3">
  <div class="container py-2 d-flex justify-content-between align-items-center">
    <a class="navbar-brand fw-semibold" href="/">weinraum</a>
    <nav aria-label="Hauptnavigation">
      <?= $menue ?? '' ?>
    </nav>
  </div>
</header>
