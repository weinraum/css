<?php $App = new \App\Libraries\App();  ?>


<div class="content content-text col-xs-12">
<div class="content-text col-xs-12 col-sm-12">

<a href="/themengarten/<?php echo $_urls; ?>" title="weiter lesen ...'">

<?php    echo $content; ?>

</a>


</div>
</div>    