<?php /** @var array $tree */ /** @var array $ctx */ $ctx['section']='winzer'; ?>
<nav class="menu menu--journal">
  <?php echo $this->include('menus/_menu'); ?>
</nav>
