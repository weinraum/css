<?php /** @var array $tree */ /** @var array $ctx */ ?>
<nav class="menu menu--main">
  <?= $this->include('menus/_menu'); ?>
</nav>
