<h1>Hallo Welt</h1>
<p>Wenn du das liest, ist <code>$contentHtml</code> korrekt verdrahtet.</p>